from django.apps import AppConfig


class RtoappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rtoApp'
